﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FanapPlus.Torange.Samples.Web.Options
{
    public class PodConfig
    {
        public string Token { get; set; }
        public int BusinessId { get; set; }
        public string ApiBaseAddress { get; set; }
        public string WebBaseAddress { get; set; }
    }
}
